﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiClientes.Tests
{
    public class ApiConfig
    {
        public static string GetEndpoint()
        {
            return "http://apiclientefinal-001-site1.htempurl.com/api";
        }
    
    }
}

